const board = document.getElementById("board");
const status = document.querySelector(".status");
const scoreX = document.getElementById("scoreX");
const scoreO = document.getElementById("scoreO");
const scoreDraw = document.getElementById("scoreDraw");

let cells = ["", "", "", "", "", "", "", "", ""];
let currentPlayer = "X";
let gameOver = false;
let scores = { X: 0, O: 0, draw: 0 };

function renderBoard() {
  board.innerHTML = "";
  for (let i = 0; i < 9; i++) {
    const cell = document.createElement("div");
    cell.classList.add("cell");
    cell.setAttribute("data-index", i);
    cell.addEventListener("click", () => makeMove(i));
    board.appendChild(cell);
  }
}

function makeMove(index) {
  if (cells[index] !== "" || gameOver) return;

  cells[index] = currentPlayer;
  const cell = board.querySelector(`.cell[data-index='${index}']`);
  cell.removeEventListener("click", () => makeMove(index)); // на всякий

  if (currentPlayer === "X") {
    cell.innerHTML = `
      <svg class="cross" viewBox="0 0 115 115">
        <line class="first" x1="15" y1="15" x2="100" y2="100"/>
        <line class="second" x1="100" y1="15" x2="15" y2="100"/>
      </svg>
    `;
  } else {
    cell.innerHTML = `
      <svg class="circle" viewBox="0 0 115 115">
        <circle r="45" cx="58" cy="58"/>
      </svg>
    `;
  }

  const win = checkWin(currentPlayer);
  if (win) {
    status.textContent = `Переміг ${currentPlayer}!`;
    highlightWin(win);
    updateScore(currentPlayer);
    gameOver = true;
    return;
  } else if (cells.every((c) => c !== "")) {
    status.textContent = "Нічия!";
    updateScore("draw");
    gameOver = true;
    return;
  }

  currentPlayer = currentPlayer === "X" ? "O" : "X";
  status.textContent = `Ходить: ${currentPlayer}`;

  if (currentPlayer === "O" && !gameOver) {
    setTimeout(botMove, 1000);
  }
}

function botMove() {
  const empty = cells
    .map((val, i) => (val === "" ? i : null))
    .filter((i) => i !== null);
  if (empty.length === 0) return;

  const choice = empty[Math.floor(Math.random() * empty.length)];
  makeMove(choice);
}

function checkWin(p) {
  const wins = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];
  return wins.find((combo) => combo.every((i) => cells[i] === p)) || null;
}

function highlightWin(combo) {
  const allCells = document.querySelectorAll(".cell");
  combo.forEach((i) => allCells[i].classList.add("winner"));
}

function updateScore(winner) {
  if (winner === "X") scores.X++;
  else if (winner === "O") scores.O++;
  else scores.draw++;

  scoreX.textContent = scores.X;
  scoreO.textContent = scores.O;
  scoreDraw.textContent = scores.draw;
}

function restartGame() {
  cells = ["", "", "", "", "", "", "", "", ""];
  currentPlayer = "X";
  gameOver = false;
  status.textContent = `Ходить: ${currentPlayer}`;
  renderBoard();
}

function toggleTheme() {
  document.body.classList.toggle("dark");
}

renderBoard();
let botLevel = 1;
let smartWins = 0;
let botSmartness = 50;

document.addEventListener("DOMContentLoaded", () => {
  const buttons = document.querySelector(".buttons");
  const settingsDiv = document.createElement("div");
  settingsDiv.innerHTML = `
    <div class="bot-settings">
      <p><strong>Рівень бота:</strong></p>
      <label><input type="radio" name="bot-level" value="1" checked> 1 — випадковий</label><br>
      <label><input type="radio" name="bot-level" value="2"> 2 — 50% точності</label><br>
      <label><input type="radio" name="bot-level" value="3"> 3 — розумний</label><br>
      <label id="lvl4-label" style="opacity: 0.5;">
        <input type="radio" name="bot-level" value="4" disabled> 4 — доступно після 1 перемоги
      </label><br>
      <div id="slider-container" style="display:none;">
        Розумність: <span id="aiPercent">50</span>%
        <input type="range" id="botSmartnessSlider" min="0" max="100" value="50">
      </div>
    </div>
  `;
  buttons.parentElement.insertBefore(settingsDiv, buttons.nextSibling);

  document.querySelectorAll("input[name='bot-level']").forEach((r) => {
    r.addEventListener("change", (e) => {
      botLevel = parseInt(e.target.value);
      document.getElementById("slider-container").style.display =
        botLevel === 4 ? "block" : "none";
    });
  });

  document
    .getElementById("botSmartnessSlider")
    .addEventListener("input", (e) => {
      botSmartness = parseInt(e.target.value);
      document.getElementById("aiPercent").textContent = botSmartness;
    });
});
function botMove() {
  if (gameOver) return;
  const empty = cells
    .map((v, i) => (v === "" ? i : null))
    .filter((i) => i !== null);
  if (!empty.length) return;

  let move;

  switch (botLevel) {
    case 1:
      move = empty[Math.floor(Math.random() * empty.length)];
      break;

    case 2:
      move =
        Math.random() < 0.5
          ? getBestMove("O")
          : empty[Math.floor(Math.random() * empty.length)];
      break;

    case 3:
      move = getBestMove("O");
      break;

    case 4:
      move =
        Math.random() * 100 < botSmartness
          ? getBestMove("O")
          : empty[Math.floor(Math.random() * empty.length)];
      break;
  }

  makeMove(move);

  if (botLevel === 3 && gameOver && status.textContent.includes("O")) {
    smartWins++;
    if (smartWins >= 1) {
      const lvl4 = document.querySelector("#lvl4-label input");
      lvl4.disabled = false;
      lvl4.parentElement.style.opacity = 1;
    }
  }
}
function getBestMove(player) {
  let bestScore = -Infinity;
  let move;
  for (let i = 0; i < 9; i++) {
    if (cells[i] === "") {
      cells[i] = player;
      let score = minimax(cells, 0, false);
      cells[i] = "";
      if (score > bestScore) {
        bestScore = score;
        move = i;
      }
    }
  }
  return move;
}

function minimax(board, depth, isMax) {
  const winner = getWinner(board);
  if (winner !== null) {
    if (winner === "O") return 10 - depth;
    if (winner === "X") return depth - 10;
    return 0;
  }

  if (isMax) {
    let maxEval = -Infinity;
    for (let i = 0; i < 9; i++) {
      if (board[i] === "") {
        board[i] = "O";
        let eval = minimax(board, depth + 1, false);
        board[i] = "";
        maxEval = Math.max(maxEval, eval);
      }
    }
    return maxEval;
  } else {
    let minEval = Infinity;
    for (let i = 0; i < 9; i++) {
      if (board[i] === "") {
        board[i] = "X";
        let eval = minimax(board, depth + 1, true);
        board[i] = "";
        minEval = Math.min(minEval, eval);
      }
    }
    return minEval;
  }
}

function getWinner(b) {
  const win = checkWin("X") || checkWin("O");
  if (win) return b[win[0]];
  if (b.every((c) => c !== "")) return "draw";
  return null;
}
